package Controller;

import java.util.Map;
import model.Passenger;
import Data.DataSingleton;
import Tools.Tool;

public class PassengerController {
    private Map<String, Passenger> passengers;

    public PassengerController() {
        this.passengers = DataSingleton.getInstance().getPassenger();
    }
    
    /**
     * lấy thông tin liên lạc hành khách, email hoặc điện thoại tùy theo chọn 0 hoặc 1
     * @return thông tin liên lạc
     */
    public String inputPassengerContactInfo(){
        String contactInfo;
        int choice = Tool.validateIntRange("choose contact info (0 for phone number, 1 for email): ", 0, 1, "out of range, please choose between 0 and 1", false);
        while (true) {
            if (choice == 0) contactInfo = Tool.validatePhoneNumber("please enter your number: ", "exceed 9 to 13 number or invalid format", false);
            else contactInfo = Tool.validateEmail("please enter your email: ", "invalid format for email", false);
            if (!existContactInfo(contactInfo)) break;
        }
        return contactInfo;
    }
    
    /**
     * kiểm tra thông tin tồn tại chưa
     * @param contactInfo
     * @return true nếu rồi, false nếu chưa
     */
    public boolean existContactInfo(String contactInfo) {
        boolean exist = false;
        if(passengers.containsKey(contactInfo)){
            System.out.println("Contact Info already exist, pls try again");
            exist = true;
        }
        return exist;
    }
    
    /**
     * thêm hành khách vào map passengers
     * @param passenger 
     */
    public void add(Passenger passenger) {
        if (passenger == null) {
            throw new IllegalArgumentException("Passenger cannot be null");
        }
        passengers.put(passenger.getContactDetails(), passenger);
        System.out.println("Passenger saved successfully!");
    }
}
