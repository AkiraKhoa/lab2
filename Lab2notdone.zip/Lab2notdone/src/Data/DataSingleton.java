package Data;

import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import model.Admin;
import model.CrewMember;
import model.Flight;
import model.Passenger;
import model.Reservation;

public class DataSingleton implements Serializable {
    private static DataSingleton instance;
    private List<Admin> admins;
    private HashMap<String, CrewMember> crewMembers;     
    private HashMap<String, Flight> flights; 
    private HashMap<String, Passenger> passengers;
    private HashMap<String, Reservation> reservations; 
    
    public DataSingleton() {
        admins = new ArrayList<>();
        crewMembers = new HashMap<>();
        flights = new HashMap<>();
        passengers = new HashMap<>();
        reservations = new HashMap<>();
    }

    public static DataSingleton getInstance() {
        if (instance == null) {
            instance = new DataSingleton();
        }
        return instance;
    }

    public Map<String, CrewMember> getCrewMember() {
        return crewMembers;
    }

    public Map<String, Flight> getFlight() {
        return flights;
    }

    public Map<String, Passenger> getPassenger() {
        return passengers;
    }
    
    public Map<String, Reservation> getReservation() {
        return reservations;
    }
    public List<Admin> getAdmin() {
        return admins;
    }
    
}
