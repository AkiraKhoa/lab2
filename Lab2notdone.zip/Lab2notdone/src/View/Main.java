package View;

import static Controller.DataController.loadDataOnStartup;
import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {

       
        MainView mainView = new MainView();
        loadDataOnStartup();
        
        mainView.showMenu();
    }
}
