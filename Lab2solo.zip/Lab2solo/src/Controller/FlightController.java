
package Controller;

import java.util.Map;
import model.Flight;
import Data.DataSingleton;
import Tools.Tool;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class FlightController {
    private Map<String, Flight> flights;
    public FlightController() {
        this.flights = DataSingleton.getInstance().getFlight();
    }
    
    /**
     * kiểm tra chuyến bay có tồn tại trong map flights dựa theo flightNumber
     * @param flightNumber
     * @return true nếu tồn tại, false nếu ko
     */
    public boolean exists(String flightNumber) {
        return flights.containsKey(flightNumber);
    }
    
    /**
     * dựa vào các tham số, tạo ra 1 chuyến bay mới
     * @param flightNumber
     * @param departureCity
     * @param destinationCity
     * @param departureTime
     * @param arrivalTime
     * @param seatNumber 
     */
    public void add(String flightNumber, String departureCity, String destinationCity, LocalDateTime departureTime, LocalDateTime arrivalTime, int seatNumber) {
        flights.put(flightNumber, new Flight(flightNumber, departureCity, destinationCity, departureTime, arrivalTime, seatNumber));
        System.out.println("Flight added successfully!");
    }
    
    /**
     * dựa vào các tham số để cập nhật chuyến bay, nếu null thì để yên
     * @param flightNumber
     * @param departureCity
     * @param destinationCity
     * @param departureTime
     * @param arrivalTime
     * @param seatNumber 
     */
    public void update(String flightNumber, String departureCity, String destinationCity, LocalDateTime departureTime, LocalDateTime arrivalTime, Integer seatNumber){
        Flight flightupdated = flights.get(flightNumber);
        if(!departureCity.isEmpty()) flightupdated.setDepartureCity(departureCity);
        if(!destinationCity.isEmpty()) flightupdated.setDestinationCity(destinationCity);
        if(departureTime != null) flightupdated.setArrivalTime(arrivalTime);
        if(arrivalTime != null) flightupdated.setArrivalTime(arrivalTime);
        if(seatNumber != null) flightupdated.setTotalSeats(seatNumber);
        System.out.println("Flight updated successfully");
    }
    
    /**
     * kiểm tra map flights có empty ko
     * @param errorMessage
     * @return true nếu có, false nếu ko
     */
    public boolean checkEmpty(String errorMessage){
        if (flights.isEmpty()) {
            System.out.println(errorMessage);
            return true;
        } else return false;
    }
    
    public Flight getFlight(String flightNumber) {
        return flights.get(flightNumber);
    }
    
    public void remove(String flightNumber){
        flights.remove(flightNumber);
        System.out.println("Flight deleted successfully!");
    }
    
    /**
     * Kiếm chuyến bay dựa theo 3 tham số được truyền vào (desireDate có thể null
     * @param departureLocation 
     * @param arrivalLocation   
     * @param desiredDate       
     * @return 1 list chuyến bay đúng ý 
     */
    public List<Flight> searchFlights(String departureLocation, String arrivalLocation, LocalDateTime desiredDate) {
        List<Flight> matchingFlights = new ArrayList<>();
        for (Flight flight : flights.values()) {
            boolean dateMatch = (desiredDate == null) || flight.getDepartureTime().equals(desiredDate);
            if (flight.getDepartureCity().equalsIgnoreCase(departureLocation) &&
                flight.getDestinationCity().equalsIgnoreCase(arrivalLocation) &&
                dateMatch) {
                matchingFlights.add(flight);
            }
        }
        if(matchingFlights.isEmpty()) {
            System.out.println("Sorry, no flights match your criteria.");
        }
        Collections.sort(matchingFlights, Comparator.comparing(Flight::getDepartureTime));  
        return matchingFlights;
    }
    
    

    /**
     * hiển thị list các chuyến bay để chọn bằng index, giảm 1 availablitySeats sau khi chọn
     * @param departureLocation
     * @param arrivalLocation
     * @param desiredDate
     * @return Chuyến bay đã chọn 
     */
    public Flight chooseFitFlight(String departureLocation, String arrivalLocation, LocalDateTime desiredDate){
        List<Flight> matchingFlights = searchFlights(departureLocation, arrivalLocation, desiredDate);
        if (matchingFlights.isEmpty()) {
            System.out.println("No matching flights found.");
            return null;
        }
        printFlightHeader();
        int index = 1;
        for (Flight flight : matchingFlights) {
        System.out.println(index + ". " + flight.toStringShowAll());
            index++;
        }
        while (true){
           int choice = Tool.validateIntRange("Select a flight by its number: ", 1, matchingFlights.size(), "Invalid choice. Please select a number from the displayed list.", false); 
           Flight selectedFlight = matchingFlights.get(choice - 1); 
           if (selectedFlight.getAvailablitySeats() <= 0) {
            System.out.println("Unfortunately, the selected flight is fully booked.");
            if (!Tool.validateYesOrNo("would you like to choose another flight(y/n): ", "Failed to choose flights", "")) {
                return null;
            }
            else {
                matchingFlights.remove(selectedFlight);
                continue;
            }
        }
            selectedFlight.setAvailablitySeats(selectedFlight.getAvailablitySeats() - 1);
            System.out.println("You've selected flight number: " + selectedFlight.getFlightNumber());
            return selectedFlight;
        }
    }
    
    /**
    * Hiển thị bố trí ghế ngồi dưới dạng hàng và cột cho một chuyến bay.
    * đánh dấu các ghế đã được đặt chỗ là "X".
    * tạo hàng "EXIT" và khoảng trống di chuyển
    * @param flight 
    */
    public void displaySeats(Flight flight) {
        int totalSeats = flight.getTotalSeats();
        int numRows = (int) ((double) totalSeats / 6);
        int exitRow = numRows / 2;

        int seatCounter = 1;  

        for (int row = 1; row <= numRows; row++) {
            if (row == exitRow) {
                System.out.println("EXIT\t\t\t\t\tEXIT");
            }

            // Display the seat row
            for (int seat = 1; seat <= 6; seat++) {
                if (seat == 3 + 1) {
                    System.out.print("\t"); 
                }
                if (seatCounter <= flight.getTotalSeats()){
                if (flight.isSeatTaken(seatCounter)) {
                    System.out.printf("|  X  |");
                } else {
                    System.out.printf("| %3d |", seatCounter);
                }
                seatCounter++;
            }
            }
            System.out.println(); 

            // Only display the row separator for non-last rows
            if (row != numRows) {
                System.out.println("+-----++-----++-----+\t+-----++-----++-----+");
            }
        }
    }
    
    /**
     * 
     * @param flightNumber
     * @return 
     */
    public Integer inputSeatNumber(String flightNumber){
        Flight currentFlight = flights.get(flightNumber);
        Integer seatNumber;
        while (true){
        seatNumber = Tool.validateIntRange("Number of seat(1-120) or enter to skip this one: ", 1, 120, "can only handle 120 seat", true);
        if (seatNumber<currentFlight.getAvailablitySeats() || seatNumber<currentFlight.getCheckInSeats()) 
            System.out.println("can't lower than " + currentFlight.getAvailablitySeats() + " and " + currentFlight.getCheckInSeats());
        else break;
        } 
        return seatNumber;
    }
    
    /**
     * lấy thông tin mã chuyến bay
     * @param prompt thông báo người dùng nhập thông tin
     * @param shouldExist true nếu cần nó exist, false nếu ko cần
     * @return mã chuyến bay
     */
    public String inputFlightNumber(String prompt, boolean shouldExist) {
        while (true) {
            String flightNumber = Tool.validateFlight(prompt, "Flight number must follow Fxyzt", false);
            boolean exists = exists(flightNumber); 

            if (shouldExist && !exists) {
                System.out.println("Flight number doesn't exist. Please try again.");
            } else if (!shouldExist && exists) {
                System.out.println("Flight number already exists. Please try again.");
            } else return flightNumber;
        }
    }
    
    public void displayAllFlights() {
        if (flights.isEmpty()) {
            System.out.println("No flights available.");
            return;
        }
        System.out.println("List of all flights:");
        for (Flight flight : flights.values()) {
            System.out.println(flight.toString());
        }
    }
    
    public void printFlightHeader() {
        System.out.println("   +------------+------------+------------+----------------------+----------------------+-------------+");
        System.out.println("   | Flight No  | Departure  | Destination| Departure Time       | Arrival Time         | Total Seats |");
        System.out.println("   +------------+------------+------------+----------------------+----------------------+-------------+");
        }
}
