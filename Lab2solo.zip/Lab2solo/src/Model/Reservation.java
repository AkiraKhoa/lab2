package model;

import java.io.Serializable;


public class Reservation implements Serializable {
    private String reservationId;
    private Passenger passenger;
    private Flight flight;
    private static int counter = 0;
    private static boolean checked;

    public Reservation(Passenger passenger, Flight flight) {
        this.reservationId = "R" + String.format("%06d", ++counter);
        this.passenger = passenger;
        this.flight = flight;
        this.checked = false;
    }

    public String getReservationId() {
        return reservationId;
    }

    public void setReservationId(String reservationId) {
        this.reservationId = reservationId;
    }

    public Passenger getPassenger() {
        return passenger;
    }

    public void setPassenger(Passenger passenger) {
        this.passenger = passenger;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight(Flight flight) {
        this.flight = flight;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        Reservation.checked = checked;
    }

    public static int getCounter() {
        return counter;
    }

    public static void setCounter(int counter) {
        Reservation.counter = counter;
    }

    @Override
    public String toString() {
        return "Reservation{" + "reservationId=" + reservationId + ", passenger=" + passenger + ", flight=" + flight + ", checked= " + checked + "}";
    }
}
