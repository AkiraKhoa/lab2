package Tools;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Tool {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Pattern FLIGHT = Pattern.compile("F[0-9]{4}");
    private static final Pattern CREW_ID = Pattern.compile("[a-zA-Z0-9]+");
    private static final Pattern ALPHANUMERIC_STRING = Pattern.compile("[a-zA-Z0-9 ]+");
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._]+@(gmail\\.com|fpt\\.edu\\.vn)$");
    private static final Pattern PHONE = Pattern.compile("^[0-9]{9,13}$");
    private static final Pattern RESERVATION_ID = Pattern.compile("R[0-9]{6}");
    
    private static String getInput(String prompt, String errorMessage, boolean allowEmpty, Pattern pattern) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) return null;
            if (pattern == null || pattern.matcher(input).matches()) return input;

            System.out.println(errorMessage);
        }
    }
    
    public static String validateFlight(String prompt, String errorMessage, boolean allowEmpty) {
        return getInput(prompt, errorMessage, allowEmpty, FLIGHT);
    }
    
    public static String validateCrewID(String prompt, String errorMessage, boolean allowEmpty) {
        return getInput(prompt, errorMessage, allowEmpty, CREW_ID);
    }
    
    public static String validateAlphanumericString(String prompt, String errorMessage, boolean allowEmpty) {
         return getInput(prompt, errorMessage, allowEmpty, ALPHANUMERIC_STRING);
    }
    
    public static String validateUsernamePassword(String prompt, String errorMessage, boolean allowEmpty) {
        return getInput(prompt, errorMessage, allowEmpty, null);
    }
    
    public static String validateEmail(String prompt, String errorMessage, boolean allowEmpty) {
        return getInput(prompt, errorMessage, allowEmpty, EMAIL);
    }
    
    public static String validatePhoneNumber(String prompt, String errorMessage, boolean allowEmpty) {
        return getInput(prompt, errorMessage, allowEmpty, PHONE);
    }
    
    public static String validateReservationID(String prompt, String errorMessage){
        return getInput(prompt, errorMessage, false, RESERVATION_ID);
    }
    
    public static Integer validateInt(String prompt, String errorMessage, boolean allowEmpty) {
        int number;
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.isEmpty() && allowEmpty) return null;
            else try {
                number = Integer.parseInt(input);
                if (number > 0) {
                    break;
                } else {
                    System.out.println("It should be greater than 0.");
                }
            } catch (NumberFormatException e) {
                System.out.println(errorMessage);
            }
        }
        return number;
    }
    
    public static boolean validateYesOrNo(String prompt, String cancelMessage, String successMessage) {
        String input;
        boolean decision=true;
        while (true) {
            System.out.print(prompt + " (y/n): ");
            input = scanner.nextLine().trim().toLowerCase();
            if ("y".equals(input) || "n".equals(input)) {
                break;
            }
            System.out.println("Invalid input. Enter 'y' for yes and 'n' for no.");
        }
        if ("n".equals(input)) {
            System.out.println(cancelMessage);
            decision=false;
        }
        if ("y".equals(input)) System.out.println(successMessage);
        return decision;
    }
    
    public static Integer validateIntRange(String prompt, int min, int max, String errorMessage, boolean allowEmpty) {
        int input;
        while (true) {
            System.out.print(prompt);
            String input1 = scanner.nextLine().trim();
            if (input1.isEmpty() && allowEmpty) return null;
            try {
                input = Integer.parseInt(input1);
                if (input >= min && input <= max) {
                    return input;
                } else {
                    System.out.println(errorMessage);
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }
    
    public static LocalDateTime validateLocalDate(String prompt, String errorMessage, boolean allowEmpty) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy H:m");
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            if (input.isEmpty() && allowEmpty) {
                return null;
            }

            try {
                return LocalDateTime.parse(input, formatter);
            } catch (DateTimeParseException e) {
                System.out.println(errorMessage);
            }
        }
    }
    
    public static LocalDateTime validateNotInPast(String prompt, String errorMessage, boolean allowEmpty) {
        LocalDateTime time;
        while (true) {
            time = validateLocalDate(prompt, "Invalid time format. Please enter again.", allowEmpty);
            if (time == null ||  time.isAfter(LocalDateTime.now())) {
                return time;
            }
            System.out.println(errorMessage);
        }
    }
    
    public static LocalDateTime validateDateAfter(String prompt, LocalDateTime afterThisDateTime, String errorMessage, boolean allowEmpty) {
        LocalDateTime time;
        while (true) {
            time = validateLocalDate(prompt, "Invalid date-time format. Please enter again.", allowEmpty);
            if (time == null || time.isAfter(afterThisDateTime)) {
                return time;
            }
            System.out.println(errorMessage);
        }
    }

}