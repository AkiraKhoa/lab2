package View;

import Controller.FlightController;
import Tools.Tool;
import java.time.LocalDateTime;


public class FlightView {
    FlightController flightController = new FlightController();
    
    public FlightView() {
    }
    
    public void start(){
        addFlight();
    }
    
    public void addFlight() {
        while (true){
            System.out.println("Enter Flight Details: ");
            String flightNumber = flightController.inputFlightNumber("Flight Number (Fxxxx): ", false);
            String departureCity =  Tool.validateAlphanumericString("Departure City: ", "nuh uh that not the name of the city", false);
            String destinationCity = Tool.validateAlphanumericString("Destination City: ", "nuh uh that not the name of the city", false);
            LocalDateTime departureTime = Tool.validateNotInPast("Departure Time (d/m/yyyy HH:mm): ", "Departure Time can't in the past", false);
            LocalDateTime arrivalTime = Tool.validateDateAfter("Arrival Time (d/m/yyyy HH:mm): ", departureTime, "Arrival Time must after Departure Time", false);
            int seatNumber = Tool.validateIntRange("Number of seat(1-120): ", 1, 120, "can only handle 120 seat", false);
            flightController.add(flightNumber, departureCity, destinationCity, departureTime, arrivalTime, seatNumber);
            flightController.displayAllFlights();
            if (!Tool.validateYesOrNo("Would you like to add more flights?", "exit Add flight", "")) {
                break;
            }
        }
    }
    
    public void updateFlight(){
        if(flightController.checkEmpty("There is 0 Flight for you to update :(((")) return;
        while(true){
            System.out.println("Update Flight: ");
            String flightNumber = flightController.inputFlightNumber("Enter Flight number you want to update: ", true);
            String departureCity =  Tool.validateAlphanumericString("Departure City or enter to skip: ", "nuh uh that not the name of the city", true);
            String destinationCity = Tool.validateAlphanumericString("Destination City or enter to skip: ", "nuh uh that not the name of the city", true);
            LocalDateTime departureTime = Tool.validateNotInPast("Departure Time (d/m/yyyy HH:mm) or enter to skip: ", "Departure Time can't in the past", true);
            LocalDateTime tempArrivalTime = flightController.getFlight(flightNumber).getArrivalTime();
            if (tempArrivalTime.isAfter(departureTime)){
                tempArrivalTime = Tool.validateDateAfter("Arrival Time (d/m/yyyy HH:mm) or enter to skip: ", departureTime, "Arrival Time must after Departure Time", true);
            } else tempArrivalTime = Tool.validateDateAfter("Arrival Time (d/m/yyyy HH:mm) can't skip this one : ", departureTime, "Arrival Time must after Departure Time", false);
            Integer seatNumber = flightController.inputSeatNumber(flightNumber);
            flightController.update(flightNumber, departureCity, destinationCity, departureTime, tempArrivalTime, seatNumber);
            if (!Tool.validateYesOrNo("Would you like to updated more flights?", "exit Update flight", "")) {
                break;
            }
        }
    }
    
    public void removeFlight(){
        if(flightController.checkEmpty("There is 0 flight for you to remove")) {
            return;
        }
        while(true){
            System.out.println("Remove Flight: ");
            String flightNumber = flightController.inputFlightNumber("Enter Flight number you want to remove: ", true);
            if(!Tool.validateYesOrNo("Are you sure you really want to remove Flight with number " + flightNumber, "cancel removing process!", "Confirm remove Flight (" + flightNumber +")")){
                flightController.remove(flightNumber);
                if(Tool.validateYesOrNo("Do you want to remove another flight? ", "Exit removing flight", ""))
                return;
            }
        }
    }
}
