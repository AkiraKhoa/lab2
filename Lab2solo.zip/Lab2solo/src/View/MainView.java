package View;

import static Controller.DataController.storeAllData;
import Tools.Tool;
import java.io.FileNotFoundException;

public class MainView {

    private final FlightView flightView;
    private final ReservationView reservationView;
    private final CheckInView checkInView;
    private final AdminView adminView;


    public MainView() {
        this.flightView = new FlightView();
        this.reservationView = new ReservationView();
        this.checkInView = new CheckInView();
        this.adminView = new AdminView();
    }

    public void showMenu() {
        while (true) {
            printMainMenu();
            int choice = Tool.validateIntRange("Enter your choice from the MAIN MENU: 1-6, or 0 to quit: ", 0, 5, "Invalid choice. Please choose a valid option.", false);
            processMainMenuChoice(choice);
        }
    }

    private void printMainMenu() {
        System.out.println("===== MAIN MENU =====");
        System.out.println("1. Flight Schedule Management");
        System.out.println("2. Passenger Reservation and Booking");
        System.out.println("3. Passenger Check-In and Seat Allocation");
        System.out.println("4. Administrator Access for System Management");
        System.out.println("5. Save all data");
        System.out.println("0. Quit");
    }

    private void processMainMenuChoice(int choice) {
        switch (choice) {
            case 1:
                flightView.start();
                break;
            case 2:
                reservationView.start();
                break;
            case 3:
                checkInView.start();
                break;
            case 4:
                adminView.start();
                break;
            case 5:
                storeAllData();
                break;
            case 0:
                System.out.println("Exiting...");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please choose a number between 0-6.");
                break;
        }
    } 
}

