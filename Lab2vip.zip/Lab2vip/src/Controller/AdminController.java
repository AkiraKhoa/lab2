package Controller;

import java.util.List;
import model.Admin;
import Data.DataSingleton;

public class AdminController {
    private List<Admin> admins;

    public AdminController() {
        this.admins = DataSingleton.getInstance().getAdmin();
        if (admins.isEmpty()) {
            admins.add(new Admin("abcd", "1234"));
        }
    }
    
    /**
     * kiểm tra tên đăng nhập và mật khẩu nhập vào khớp không
     * @param username tên đăng nhập 
     * @param password mật khẩu 
     * @return true nếu đúng, false nếu sai
     */
    public boolean validateAdminCredentials(String username, String password) {
        for (Admin admin : admins) {
            if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * đưa 1 admin được add vào list admins
     * @param admin 
     */
    public void addNewAdmin(Admin admin) {
        if (admin != null) {
            admins.add(admin);
            System.out.println("Admin added successfully!");
        } else {
            System.out.println("Failed to add admin.");
        }
    }
    
    

}
