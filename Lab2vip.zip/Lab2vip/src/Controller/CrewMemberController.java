package Controller;

import java.util.Map;
import model.CrewMember;
import Data.DataSingleton;
import Tools.Tool;
import model.CrewMember.CrewRole;
import model.Flight;

public class CrewMemberController {
    private Map<String, CrewMember> crewMembers;
    private FlightController flightController = new FlightController();
    public CrewMemberController() {
        this.crewMembers = DataSingleton.getInstance().getCrewMember();
    }
    
    /**
     * thêm 1 crew member vào map crewMembers cũng như chuyển crew member đó vào chuyến bay đã được phân
     * @param crewMember 
     */
    public void add(CrewMember crewMember) {
    crewMembers.put(crewMember.getCrewId(), crewMember);
    Flight flight = flightController.getFlight(crewMember.getFlightNumber());
    if (flight == null) {
        System.out.println("flight is null");
        return;
    }
    flight.assignCrewMember(crewMember);
    System.out.println("Crew member added successfully!");
}

    /**
     * check tồn tại của crew member trong map crewmembers
     * @param id của crew member được kiểm tra
     * @return true nếu có, false nếu không
     */
    public boolean exists(String id){
        return crewMembers.containsKey(id);
    }
    
    /**
     * dùng để lấy ID của crew member
     * @param prompt
     * @param shouldExist true nếu nên tồn tại, 
     * @return 
     */
    public String inputCrewID(String prompt, boolean shouldExist) {
        while (true) {
            String id = Tool.validateID(prompt, "ID can't be empty", false);
            boolean exists = exists(id);
            if (shouldExist && exists) {
                System.out.println("Crew member with ID: " + id + " already exists!");
                continue;
            } else if (!shouldExist && !exists) {
                System.out.println("Crew member with ID: " + id + " doesn't exist!");
                continue;
            } 
            return id;
        }
    }
    
    public void update(String Id, String name, CrewRole role, String flightNumber){
        CrewMember crewMembertupdated = crewMembers.get(Id);
        if(!name.isEmpty()) crewMembertupdated.setName(name);
        if(role != null) crewMembertupdated.setRole(role);
        if(flightNumber != null) {
            Flight flight = flightController.getFlight(crewMembertupdated.getFlightNumber());
            flight.removeCrewMember(crewMembertupdated.getCrewId());
            crewMembertupdated.setFlightNumber(flightNumber);
            flight.assignCrewMember(crewMembertupdated);
        }
        System.out.println("Flight updated successfully");
    }
    
    public void remove(String Id){
        CrewMember crewMember = crewMembers.get(Id);
        Flight flight = flightController.getFlight(crewMember.getFlightNumber());
        flight.removeCrewMember(crewMember.getCrewId());
        crewMembers.remove(Id);
        System.out.println("Flight deleted successfully!");
    }
    
    public boolean checkEmpty(String errorMessage){
        if (crewMembers.isEmpty()) {
            System.out.println(errorMessage);
            return true;
        } else return false;
    }
}




