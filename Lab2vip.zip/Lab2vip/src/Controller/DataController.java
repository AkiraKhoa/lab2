package Controller;

import Data.DataSingleton;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.Map;
import model.Admin;
import model.CrewMember;
import model.Flight;
import model.Passenger;
import model.Reservation;

public class DataController {
    public static Object loadDataFromFile(String filePath) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            return ois.readObject(); 
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
            return null;
        }
    }

    /**
    * Lưu data vào file 
    * @param filePath đường dẫn tới file được lưu
    * @param data data sẽ được lưu vào file
    */
    public static void saveDataToFile(String filePath, Object data) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(data); 
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }
    
    /**
    * Loads application data from files during startup and populates the DataSingleton instance.
    * Load data từ 2 file Product và Warehouse gồm:
    * hashmap products chứa Product.
    * hashmap importreceipts chứa import receipts.
    * hashmap exportreceipts chứa export receipts.
    * 
    * 
    */
    public static void loadDataOnStartup() {
        DataSingleton instance = DataSingleton.getInstance();

        List<Admin> admins = (List<Admin>) loadDataFromFile("./Admin.dat");
        if (admins != null) {
            instance.getAdmin().addAll(admins);
        }

        Map<String, Flight> flights = (Map<String, Flight>) loadDataFromFile("./Flight.dat");
        if (flights != null) {
            instance.getFlight().putAll(flights);
        }

        Map<String, Reservation> reservations = (Map<String, Reservation>) loadDataFromFile("./Reservation.dat");
        if (reservations != null) {
            instance.getReservation().putAll(reservations);
        }
        
        Map<String, Passenger> passengers = (Map<String, Passenger>) loadDataFromFile("./Passenger.dat");
        if (passengers != null) {
            instance.getPassenger().putAll(passengers);
        }
        
        Map<String, CrewMember> crewMembers = (Map<String, CrewMember>) loadDataFromFile("./CrewMember.dat");
        if (crewMembers != null) {
            instance.getCrewMember().putAll(crewMembers);
        }
        
        Integer loadedCounter = (Integer) loadDataFromFile("./Counter.dat");
            if (loadedCounter != null) {
            Reservation.setCounter(loadedCounter);
        }
    }
    
    /**
    * Stores all application data from the DataSingleton instance to respective files.
    * Lưu tất cả dữ liệu sau khi đã sửa đổi vào 2 file Product và Warehouse bao gồm:
    * hashmap products chứa Product.
    * hashmap importreceipts chứa import receipts.
    * hashmap exportreceipts chứa export receipts.
    * Lưu thành công sẽ có thông báo xác nhận
    * The method performs the following steps:
    */
    public static void storeAllData() {
        DataSingleton instance = DataSingleton.getInstance();

        saveDataToFile("./Admin.dat", instance.getAdmin());
        saveDataToFile("./CrewMember.dat", instance.getCrewMember());
        saveDataToFile("./Flight.dat", instance.getFlight());
        saveDataToFile("./Passenger.dat", instance.getPassenger());
        saveDataToFile("./Reservation.dat", instance.getReservation());
        saveDataToFile("./Counter.dat", Reservation.getCounter());



        System.out.println("Data saved successfully!");
    }


}
