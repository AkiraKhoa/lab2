package model;

import java.io.Serializable;


public class CrewMember implements Serializable {
    private String name;
    private String crewId;
    private CrewRole role; 
    private String flightNumber;

    public CrewMember(String name, String crewId, CrewRole role, String flightNumber) {
        this.name = name;
        this.role = role;
        this.crewId = crewId;
        this.flightNumber = flightNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCrewId() {
        return crewId;
    }

    public void setCrewId(String crewId) {
        this.crewId = crewId;
    }

    public CrewRole getRole() {
        return role;
    }

    public void setRole(CrewRole role) {
        this.role = role;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }
    
    public enum CrewRole {
    PILOT,
    FLIGHT_ATTENDANT,
    GROUND_STAFF,
}
     
}
