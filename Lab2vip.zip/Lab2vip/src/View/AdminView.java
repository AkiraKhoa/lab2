package View;

import Controller.AdminController;
import Controller.CrewMemberController;
import Controller.FlightController;
import Tools.Tool;
import model.Admin;
import model.CrewMember;
import model.CrewMember.CrewRole;

public class AdminView {
    AdminController adminController = new AdminController(); 
    FlightView flightView = new FlightView();
    CrewMemberController crewMemberController = new CrewMemberController();
    FlightController flightController = new FlightController();
    
    public AdminView(){
    }
    
    public void start() {
        if (!authenticateAdmin()) {
            System.out.println("Authentication failed. Exiting admin menu.");
            return;
        }
        while (true) {
            printAdminMenu();
            int choice = Tool.validateIntRange("Enter your choice from the ADMIN MENU: 1-5, or 0 to go back: ", 0, 5, "Invalid choice. Please choose a valid option.", false);
            if (choice == 0) {
                System.out.println("Exiting admin menu...");
                break;
            }
            processAdminMenuChoice(choice);
        }
    }
    
    private void printAdminMenu() {
        System.out.println("===== ADMIN MENU =====");
        System.out.println("1. Update Flight");
        System.out.println("2. Remove Flight");
        System.out.println("3. Add Crew Member");
        System.out.println("4. Update Crew Member");
        System.out.println("5. Remove Crew Member");
        System.out.println("0. Go Back");
    }

    private void processAdminMenuChoice(int choice) {
        switch (choice) {
            case 1:
                flightView.updateFlight();
                break;
            case 2:
                flightView.removeFlight();
                break;
            case 3:
                addCrewMember();
                break;
            case 4:
                updateCrewMember();
                break;
            case 5:
                removeCrewMember();
                break;
            case 6:
                addAdmin();
                break;
            default:
                System.out.println("Invalid choice. Please choose a number between 0-5.");
                break;
        }
    }
    
    
    public boolean authenticateAdmin(){
        String username = Tool.validateUsernamePassword("Enter admin username: ", "username can't empty", false);
        String password = Tool.validateUsernamePassword("Enter password: ", "password can't empty", false);
        return adminController.validateAdminCredentials(username, password);
    }
    
    public void addCrewMember() {
        while (true) {
            System.out.println("Enter Crew Member Details: ");
            String id = crewMemberController.inputCrewID("Enter ID of the crew member: ", true);
            String name = Tool.validateAlphanumericString("Name: ", "Name can't be empty", false);
            int choice = Tool.validateIntRange("Enter your choice (1-3) Pilot; Flight attendant; Ground staff: ", 1, 3, "Invalid choice. Please choose from 1 to 3.", false);
            CrewRole selectedCrewRole = CrewRole.values()[choice - 1];
            String flightNumber = flightController.getFlightNumber("Enter Flight number you want to crew member do: ", true);
            crewMemberController.add(new CrewMember(id, name, selectedCrewRole, flightNumber));

            if (!Tool.validateYesOrNo("Would you like to add more crew members?", "Exit add crew member")) {
                break;
            }
        }
    }
    
    public void updateCrewMember() {
        if(crewMemberController.checkEmpty("There is 0 crew member for you to update :(((")) return;
        while (true) {
            String id = crewMemberController.inputCrewID("Enter ID of the crew member you want to update: ", false);
            String name = Tool.validateAlphanumericString("Name (or enter to skip): ", "Name can't be empty", true);
            Integer choice = Tool.validateIntRange("Enter your choice (1-3) for role (or enter to skip): ", 1, 3, "Invalid choice. Please choose from 1 to 3.", true);
            CrewRole selectedCrewRole = (choice != null) ? CrewRole.values()[choice - 1] : null;
            String flightNumber = flightController.getFlightNumber("Enter new Flight number (or enter to skip): ", true);

            crewMemberController.update(id, name, selectedCrewRole, flightNumber);

            if (!Tool.validateYesOrNo("Would you like to update more crew members?", "Exit update crew member")) {
                break;
            }
        }
    }

    public void removeCrewMember() {
        if(crewMemberController.checkEmpty("There is 0 crew member for you to remove ")) return;
        while (true) {
            String id = crewMemberController.inputCrewID("Enter ID of the crew member you want to remove: ", false);

            if (Tool.validateYesOrNo("Are you sure you want to remove the crew member with ID " + id + "?", "Cancel removing process!")) {
                crewMemberController.remove(id);
                System.out.println("Crew member removed successfully.");
            }

            if (!Tool.validateYesOrNo("Would you like to remove more crew members?", "Exit remove crew member")) {
                break;
            }
        }
    }
    
    public void addAdmin() {
        while (true) {
            System.out.println("Enter New Admin Details: ");
            String username = Tool.validateAlphanumericString("Username: ", "Username can't be empty", false);
            String password = Tool.validateAlphanumericString("Password: ", "Password can't be empty", false);
            adminController.addNewAdmin(new Admin(username, password));

            if (!Tool.validateYesOrNo("Would you like to add more admins?", "Exit add admin")) {
                break;
            }
        }
    }
    
}

    
    
    

