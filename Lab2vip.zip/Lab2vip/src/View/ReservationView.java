package View;
import Controller.FlightController;
import Controller.PassengerController;
import Controller.ReservationController;
import Tools.Tool;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import model.Flight;
import model.Passenger;
import model.Reservation;


public class ReservationView {
    FlightController flightController = new FlightController();
    ReservationController reservationController = new ReservationController();
    PassengerController passengerController = new PassengerController();
    
    public ReservationView() {
    }
    
    public void start() {
    makeReservation();
}
    
    public void makeReservation() {
        if(flightController.checkEmpty("0 flight was add how can you make a reservation huh? ")) return;
        System.out.println("---- Make a Flight Reservation ----");
        String departureLocation = Tool.validateAlphanumericString("Enter departure location: ", "Invalid location.", false);
        String arrivalLocation = Tool.validateAlphanumericString("Enter arrival location: ", "Invalid location.", false);
        LocalDateTime desiredDate = Tool.validateNotInPast("Enter desired date of flight (d/m/yyyy HH:mm) or enter to skip: ", "Entered date/time is in the past.", true);
        Flight selectedFlight = flightController.chooseFitFlight(departureLocation, arrivalLocation, desiredDate);
        if (selectedFlight == null) {
            System.out.println("Reservation process aborted.");
            return;
        }
        
        String passengerName = Tool.validateAlphanumericString("Enter your name: ", "Invalid name. Please use alphanumeric characters.", false);
        String passengerContactInfo = passengerController.getPassengerContactInfo();
        Passenger passenger = new Passenger(passengerName, passengerContactInfo);
        passengerController.add(passenger);
        reservationController.add(new Reservation(passenger, selectedFlight));
        reservationController.showAll();
    }
}
